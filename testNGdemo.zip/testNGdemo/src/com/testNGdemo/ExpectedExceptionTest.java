package com.testNGdemo;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.demo.testNG.MessageUtil;

public class ExpectedExceptionTest {
	 String message = "Manisha";	
	    MessageUtil messageUtil = new MessageUtil(message);
		   
	    @Test(expectedExceptions = ArithmeticException.class)
	    public void testPrintMessage() {	
	        System.out.println("Inside testPrintMessage()");     
	        messageUtil.printMessage();     
	   }
	   @Test
	   public void testSalutationMessage() {
	      System.out.println("Inside testSalutationMessage()");
	      message = "Hi!" + "Manisha";
	      Assert.assertEquals(message,messageUtil.Message1());
	   }
	   
	   @Test(expectedExceptions = IllegalArgumentException.class, expectedExceptionsMessageRegExp="NullPoint")
	    public static void testException(){
	        throw new IllegalArgumentException("NullPoint");
	    }
//	    public static void main(String[] args) {
//			System.out.println("a");
//			testException();
//		}

}
