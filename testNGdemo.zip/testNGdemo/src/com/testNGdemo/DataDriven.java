package com.testNGdemo;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class DataDriven {
    @Test
    @Parameters("myName")
    public void parameterTest(String myName) {
        System.out.println("Parameter value is : " + myName);
    }
}


