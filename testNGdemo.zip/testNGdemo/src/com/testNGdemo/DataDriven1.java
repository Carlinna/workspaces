package com.testNGdemo;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataDriven1 {
	@DataProvider(name="user")
	public Object[][] user () {
		
		return new Object[][]{
				{"root","1234567"},
				{"test1","7654321"},
				{"test2","123456789"}
			
		};
		
	}
	@Test(dataProvider="user")
	public void test1(String username,String password){
		System.out.println("sdf"+username+"��ĵ�"+ password);
	}


}
