package com.testNGdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Created by Qj on 2015/07/27.
 */
public class ConnOracleTest {
    String url = "jdbc:oracle:thin:@10.100.1.204:1521:ebr01";
    String username = "eam_hc2";
    String password = "eam_hc2";
    Connection connection = null;


    public ResultSet conn(String sql) throws  Exception{
        ResultSet rs = null;
            Class.forName("oracle.jdbc.driver.OracleDriver");
            connection = DriverManager.getConnection(url, username, password);
            Statement st = connection.createStatement();
            rs = st.executeQuery(sql);
        return rs;
    }

    public static void main(String[] args){
        ConnOracleTest cot = new ConnOracleTest();
        try{
            ResultSet rs = cot.conn("SELECT * FROM pub_users");
            while (rs.next()){
                System.out.print(rs.getString(3) + " " );
                System.out.println();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
