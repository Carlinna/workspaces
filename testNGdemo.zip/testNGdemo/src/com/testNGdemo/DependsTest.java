package com.testNGdemo;



import org.testng.Assert;
import org.testng.annotations.Test;

public class DependsTest {

    @Test
    public void setupEnv(){
        System.out.println("this is setup Env");
        Assert.assertEquals(1, 1);
    }
    
    @Test(dependsOnMethods = {"setupEnv"})
    public void testMessage(){
        System.out.println("setupEnv失败不执行，通过执行");
    }
    @Test
    public void demo1(){
        System.out.println("不管你们，我一直执行");
    }

}
