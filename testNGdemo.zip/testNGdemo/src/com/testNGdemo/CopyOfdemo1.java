package com.testNGdemo;

import org.testng.annotations.Test;

public class CopyOfdemo1 {
	@Test
	public void afterClass() {
		System.out.println("this is after class");
	}

	@Test
	public void beforeClass() {
		System.out.println("this is before class");
	}

	@Test
	public void TestNgLearn() {
		System.out.println("this is TestNG test case");
	}

}
