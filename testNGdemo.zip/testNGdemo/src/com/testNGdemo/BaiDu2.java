package com.testNGdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class BaiDu2 {
	public WebDriver Driver;

	@BeforeClass
	public void BeforeClass(){
		System.out.println("beforeclass");
	}
	
	@BeforeMethod
	public void setup() {
		try
		{
		 System.setProperty("webdriver.chrome.driver","D://home//eclipse_workspace//testNGdemo//adc//chromedriver.exe");
		 Driver=new ChromeDriver();
		}catch(Exception e)
		{
			System.out.print(e.getMessage());
		}
//		Driver = new FirefoxDriver();
		Driver.manage().window().maximize();
		Driver.navigate().to("http://www.baidu.com");		
	}
	
	@DataProvider(name="user")
	public Object[][] user () {
		
		return new Object[][]{
				{"root"},
				{"test1"},
				{"test2"}
			
		};
		
	}
	
	@Test(dataProvider="user")
	public void test(String info){
		WebElement Text= Driver.findElement(By.name("wd"));
		Text.sendKeys(info);

		try {
			Thread.sleep(3000);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Text.clear();
		try {
			Thread.sleep(3000);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
   
	@AfterMethod
	public void close() {
		Driver.close();
	}

	@AfterClass
	public void quit() {
		Driver.quit();
	}
}
