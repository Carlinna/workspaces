package com.testNGdemo;

import org.testng.annotations.Test;

public class GroupTest {
	@Test(groups = { "systemtest" })
	public void SysGroup1() {
		System.out.println("this is group test systemtest ");
	}
		@Test(groups = { "systemtest" })
		public void SysGroup2() {
			System.out.println("this is group test systemtest2 ");
		}

	@Test(groups = { "functiontest" })
	public void functGroup1() {
		System.out.println("this is group test functiontest group");
	}

	@Test(groups = { "functiontest",  "systemtest"})
	public void functGroup2() {
		System.out.println(" functGroup2 functiontest +systemtest");
	}
	@Test
	public void functGroup3() {
		System.out.println(" functGroup2 functiontest +systemtest233");
	}

}
