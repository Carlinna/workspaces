package com.testNGdemo;

import org.testng.annotations.Test;

public class IgnoreTest {

	@Test(enabled = false)
	public void testIgnore() {
		System.out.println("This test case will ignore");
	}
	@Test
	public void demo1() {
		System.out.println("I DO");
	}

}
