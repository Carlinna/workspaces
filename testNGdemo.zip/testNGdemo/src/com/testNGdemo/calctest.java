package com.testNGdemo;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class calctest {
	 private static Calculator calc = new Calculator();

	    @BeforeTest
	    public void Setup() {
	        System.out.println("Setup the environment!");
	    }

	    @AfterTest
	    public void Cleanup() {
	        System.out.println("Cleanup the environment!");
	    }

	    /*
	    @Test
	    public void testAdd() {
	        int result = calc.add(1, 2);
	        assert 3 == result;
	    }

	    @Test
	    public void testSub(){
	        int result = calc.sub(1,2);
	        assert -1 == result;
	    }

	    @Test
	    public void testMultiply(){
	        int result = calc.multiply(1,2);
	        assert 2 == result;
	    }

	    @Test
	    public void testDivide() throws Exception{
	        int result = calc.divide(4,2);
	        assert 2 == result;
	    }
	*/
//	    @Test
//	    public void test_max_1_2_3()
//	    {
//	        int result = calc.getMax(1,2,3);
//	        assert 3 == result;
//	    }
//
//	    @Test
//	    public void test_max_1_3_2()
//	    {
//	        int result = calc.getMax(1,3,2);
//	        assert 3 == result;
//	    }
//
//	    @Test
//	    public void test_max_0_0_0()
//	    {
//	        int result = calc.getMax(0,0,0);
//	        assert 0 == result;
//	    }

	    @DataProvider(name = "datasource")
	    public Object[][] createDataSource(){

	        return new Object[][]{
	                {1,2,3,3},
	                {2,1,3,3},
	                {5,3,4,5},
	                {2,3,2,3}
	        };
	    }

	    @Test(dataProvider = "datasource")
	    public void verifyGetMaxResult(int fir, int sec, int thd,int result)
	    {
	         assert result == calc.getMax(fir,sec,thd);
	    }

}
