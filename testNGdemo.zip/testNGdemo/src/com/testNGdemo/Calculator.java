package com.testNGdemo;

public class Calculator {
	/*
    public int add(int fir, int sec)
    {
        return fir + sec;
    }

    public int sub(int fir, int sec)
    {
        return fir - sec;
    }

    public int multiply(int fir, int sec)
    {
        return fir * sec;
    }

    public int divide(int fir, int sec) throws Exception
    {
        if(0 == sec)
        {
            throw new Exception("divisor can not be zero");
        }
        return fir/sec;
    }
*/
    public int getMax(int x, int y, int z)
    {
        if (x >= y)
        {
            if(x >= z){
                return x;
            }
            else {
                return z;
            }
        }
        else
        {
            if(y >= z)
            {
                return y;
            }
            else
            {
                return z;
            }
        }
    }

}
