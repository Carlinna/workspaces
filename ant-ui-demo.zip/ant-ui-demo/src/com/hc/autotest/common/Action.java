package com.hc.autotest.common;

import java.util.HashMap;

import com.hc.autotest.page.Page;
import com.hc.autotest.selenium.clientapi.MyWebDriver;
import com.hc.autotest.util.*;

public class Action {
	String testCasePath; 
	String sheetName; 	
	public oTestData otestdata;
	public MyWebDriver MyDriver;
	public Page page;
	
	public Action(AutoTestUtil driver,String testCasePath, String sheetName, int dataList) {
		this.testCasePath = testCasePath;
		this.sheetName = sheetName;
		HashMap<String, Integer> hm = getRowWithTestData(testCasePath, sheetName);		
		MyDriver = new MyWebDriver(driver);
		page= new Page(MyDriver);
		otestdata = new oTestData(testCasePath,sheetName,dataList,hm);
	}

	/**
	 * 获取数据字段所在行的位置，返回	
	 * @param testCasePath
	 * @param sheetName
	 * @return
	 */
	public HashMap<String, Integer> getRowWithTestData(String testCasePath,String sheetName){
		ExcelUtil excelUtil = new ExcelUtil();
		String testData="";
		int rows=0;
		HashMap<String, Integer> hm= new HashMap<String, Integer>();
		do {
			testData= excelUtil.ReadExcel(testCasePath, sheetName, 0, rows);
			hm.put(testData, rows);
			rows=rows+1;
		} while ( !excelUtil.isEmpty(testCasePath, sheetName, 0, rows));
		return hm;
	}

}