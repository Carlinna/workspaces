package com.hc.autotest.testaction;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.hc.autotest.common.Action;
import com.hc.autotest.util.AutoTestUtil;

public class LoginAction extends Action {

	public LoginAction(AutoTestUtil driverPar, String testCasePath,
			String sheetName, int dataList) {
		super(driverPar, testCasePath, sheetName, dataList);
		// TODO Auto-generated constructor stub
	}
	
	public void commonMthd()
	{
		System.out.print("开始登录");
		String Url = "http://10.100.1.65:8080/app/";
		MyDriver.get(Url);
		MyDriver.WaitForElement(By.id("j_username"));
		MyDriver.Type(By.id("j_username"), otestdata.GetItem("用户名"));
		MyDriver.Type(By.id("j_password"), otestdata.GetItem("密码"));
		MyDriver.Click(By.xpath("//button[@id='btnSubmit']"));
	}

}
