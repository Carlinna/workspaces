package com.hc.autotest.testaction;
import com.hc.autotest.common.Action;
import com.hc.autotest.util.AutoTestUtil;

public class ExitAction extends Action {

	public ExitAction(AutoTestUtil driverPar, String testCasePath,
			String sheetName, int dataList) {
		super(driverPar, testCasePath, sheetName, dataList);
		// TODO Auto-generated constructor stub
	}
	
	public void commonMthd()
	{
		System.out.println("流程结束");
		//MyDriver.quit();
		//MyDriver =null;
		//System.out.println("close---");
	}

}
