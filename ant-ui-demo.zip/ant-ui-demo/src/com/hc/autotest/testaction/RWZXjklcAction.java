package com.hc.autotest.testaction;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.hc.autotest.common.Action;
import com.hc.autotest.util.AutoTestUtil;

public class RWZXjklcAction extends Action {

	public RWZXjklcAction(AutoTestUtil driverPar, String testCasePath,
			String sheetName, int dataList) {
		super(driverPar, testCasePath, sheetName, dataList);
		// TODO Auto-generated constructor stub
	}
	
	public void commonMthd()
	{
		
		page.ClickFrame("任务中心-流程监控 ");
		MyDriver.Type(By.name("applyCode"), otestdata.GetItem("申请编号"));
		MyDriver.Type(By.name("custName"), otestdata.GetItem("客户名称"));
		MyDriver.Type(By.name("idNum"), otestdata.GetItem("证件号码"));
		page.SearchButton("查询");
		page.LeaveFrame("流程监控");
	}

}
