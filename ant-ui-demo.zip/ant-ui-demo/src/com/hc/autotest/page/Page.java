package com.hc.autotest.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.hc.autotest.selenium.clientapi.MyWebDriver;

public class Page {
	
	private MyWebDriver driver;

	/**
	 * 选择菜单
	 * @param driver
	 * @param menu
	 */
	public Page(MyWebDriver driver)
	{
		this.driver=driver;
	}
	
	/**
	 * 进入当前Table
	 * @param menu
	 */
	public void ClickFrame(String menu)
	{
		driver.pause(1000);
		System.out.print(menu);
		String menu2=menu;
		if(menu.contains("-"))
		{
			String[] str = menu.split("-");
			String menu1Xpath = "//ul[@id='nav']/descendant::a[text()=' " +str[0].trim()+"']";
			WebElement menu1WebElment = driver.findElement(By.xpath(menu1Xpath));
			menu1WebElment.click();
			driver.pause(1000);
			menu2=str[1];
		}
		String menu2Xpath = "//ul[@id='nav']/descendant::a[text()='" +menu2.trim()+" ']";
		WebElement menu2WebElment = driver.findElement(By.xpath(menu2Xpath));
		menu2WebElment.click();
		driver.enterFrame("//*[@id='mainTab']/div[2]/div[2]/div/iframe");
	}
	
	/**
	 * 退出当前Table
	 * @param menu
	 */
	public void LeaveFrame(String menu)
	{
		driver.pause(1000);
		driver.leaveFrame();
		//String menu1Xpath = "//span[text()='"+menu+"']";
		String menu1Xpath="//li[@class='tabs-selected']/a[@class='tabs-close']";
		driver.pause(1000);
		driver.Click(By.xpath(menu1Xpath));
	}
	
	/**
	 * 查询界面操作
	 * @param str
	 */
	public void SearchButton(String str)
	{
		driver.pause(1000);
		String ButtonXpath="//span[@class='l-btn-left']//span[text()='"+str+"']";
		WebElement menu1WebElment = driver.findElement(By.xpath(ButtonXpath));
		menu1WebElment.click();
		driver.pause(3000);
	}
}



