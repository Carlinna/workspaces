package com.hc.autotest.run;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Iterator;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.hc.autotest.selenium.clientapi.*;
import com.hc.autotest.util.*;

/**
 * The demo to show TestNg's basic usage
 */
public class TestNgRun1 {
	private AutoTestUtil driver = new AutoTestUtil();
	private GlobalSettings ActionProp = new GlobalSettings("Action.properties");
	private GlobalSettings DriverProp = new GlobalSettings("Prop.properties");
	private GlobalSettings TestCaseNameProp = new GlobalSettings("testcasename.properties");
	private ExcelUtil excelUtil = new ExcelUtil();
	private oTestMain otestmain = new oTestMain();
	private SqlServer sqlhandle = new SqlServer();
	private String NewExcel;

	private int dataList;	
	
	//@BeforeClass
	public void doBeforeClass() {
		driver.StartWebDriver();
	}
	
	@Test(dataProvider = "data")
	/** 
	 * @param excelpath:excel存在路径
	 * @param left:excel中指定flow的top row
	 * @param right:excel中指定flow的bottom row
	 * @param runlist:当前指定流的本次循环次数
	 */
	public void doTest(String FlowInfo, int runlist) {
		doBeforeClass();
		long startTime = System.currentTimeMillis();
		SimpleDateFormat createTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		FileUtil fileUtil = new FileUtil();
		String[] FlowStr = FlowInfo.substring(FlowInfo.indexOf('[')+1,FlowInfo.indexOf(']')).split("-");
		int left=Integer.parseInt(FlowStr[0]);
		int right=Integer.parseInt(FlowStr[1]);
		String excelpath=this.NewExcel;
		String businessFlowID = excelUtil.ReadExcel(excelpath, "Main", 0, left);
		String businessFlowName = excelUtil.ReadExcel(excelpath, "Main", 1, left);
		String logfile = "log/"+getClass().getName();		
		fileUtil.deleteFile(logfile);
		try {
			//循环组件
			for(int row = left; row <= right; row++){			
				//判断组件是否为Enable，若是则运行
				String actEnable = excelUtil.ReadExcel(excelpath, "Main", 6,row);
				
				if(actEnable.equalsIgnoreCase("Enable")){
					int DataList = otestmain.getCurrentDataList(excelpath, runlist, row);
					dataList = DataList;
					String actionName = excelUtil.ReadExcel(excelpath,"Main", 3, row);
					boolean isActRun = otestmain.isActionRun(excelpath, actionName, DataList);
					if(!isActRun){continue;}					
					driver.SetActionName(excelpath, actionName, dataList);
					String act_name = ActionProp.getProperty(actionName);
					//根据组件名用反射机制调用组件
					try {
							Class action = Class.forName(act_name);			
							Class[] pType = new Class[]
									{ AutoTestUtil.class, String.class,String.class,int.class};
							Constructor ctor = action.getConstructor(pType);	
							Object obj[] = new Object[]
									{driver, excelpath, actionName, DataList };
							Object actobj = ctor.newInstance(obj);
							Method mthd = actobj.getClass().getMethod("commonMthd");
							mthd.invoke(actobj);						
						}catch (Exception e)
						{	e.printStackTrace();
							Assert.fail("use reflact to call action fail!");
						}
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			ExcelUtil excelUtil = new ExcelUtil();
			excelUtil.setForceFormulaRecalculation(excelpath);
			if(DriverProp.getProperty("insertSQL").equalsIgnoreCase("YES")){
				//生成log文件
				long runningTime = System.currentTimeMillis() - startTime;
				driver.CommonLog(excelpath, businessFlowID, businessFlowName, runlist, runningTime, createTime, getClass().getName());
				//将生成的log文件写入数据库对应表
				sqlhandle.insertLog(logfile);
				sqlhandle.insertErrorLog(logfile);
			}
			doAfterClass();
		}
	}
		
	//@AfterClass(alwaysRun = true)
	public void doAfterClass() {
		MyWebDriver mywebdriver = new MyWebDriver(driver);
		mywebdriver.quit();
	}
	
	@DataProvider(name = "data")
	public Iterator data() {			
		/**
		 * 根据excel整理DateProvider
		 * @return
		 * 		返回DateProvider数组
		 */			
		FileUtil fileUtil = new FileUtil();
		SrcDataProvider datapro = new SrcDataProvider();		
		String date = otestmain.getNowTime("yyyy-MM-dd HHmmss");
//		String oldExcel = "";
		String oldExcel =TestCaseNameProp.getProperty("TestNgRun1");
		String oldExcelName = new File(oldExcel).getName();
		String newPath = "C://testTemp//";
		fileUtil.createDir(newPath);
		NewExcel = newPath + oldExcelName + date + ".xls";
		return datapro.SrcDataPro(oldExcel,NewExcel);
	}
}
