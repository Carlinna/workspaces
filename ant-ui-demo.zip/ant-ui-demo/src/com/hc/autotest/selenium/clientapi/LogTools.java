/*
 * Copyright (c) 2012-2013 NetEase, Inc. and other contributors
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package com.hc.autotest.selenium.clientapi;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;

import com.hc.autotest.util.AutoTestUtil;

/**
 * Log Tools
 * @author Sqou
 */
public class LogTools {
	
	public Logger logger = Logger.getLogger(LogTools.class
			.getName());
	private GlobalSettings DriverProp = new GlobalSettings("Prop.properties");
	
	public void log(String logText) {
		System.out.println("[" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(System.currentTimeMillis())) + "] " + logText);
	}

	public String screenShot(AutoTestUtil driver) {
		String dir = "screenshot"; // TODO
		String time = new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
		String screenShotPath = dir + File.separator + time + ".png";
		String Output = "test-output" + File.separator + "report" + File.separator + "screenshot" + File.separator + time + ".png";

		WebDriver augmentedDriver = null;
		if (DriverProp.getProperty("BrowserCoreType").equals("FireFox")  || DriverProp.getProperty("BrowserCoreType").equals("IE")) {
			augmentedDriver = driver.getWebDriver();
			augmentedDriver.manage().window().setPosition(new Point(0, 0));
			augmentedDriver.manage().window().setSize(new Dimension(9999, 9999));
		} else if (DriverProp.getProperty("BrowserCoreType").equals("Chrome")) {
			augmentedDriver = new Augmenter().augment(driver.getWebDriver());
		} else {
			return "Incorrect browser type";
		}

		try {
			File sourceFile = ((TakesScreenshot) augmentedDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(sourceFile, new File(screenShotPath));
			FileUtils.copyFile(sourceFile, new File(Output));
		} catch (Exception e) {
			e.printStackTrace();
			return "Failed to screenshot";
		}

		return screenShotPath;
	}
}
