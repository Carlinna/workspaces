package com.hc.autotest.selenium.clientapi;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * 实例化WebDriver
 * @author sqou
 *
 */
public class MyWebDriverFactory {
	private WebDriver webdriver;
	private Logger logger = Logger.getLogger(MyWebDriverFactory.class
			.getName());
	private GlobalSettings DriverProp = new GlobalSettings("Prop.properties");											
	
	public WebDriver getWebDriverClient() {
		String browserType = DriverProp.getProperty("BrowserCoreType");
		logger.info(browserType +" Driver Start Run:");
		if (webdriver == null) {
			if (browserType.equals("Firefox")) {
				try
				{
					webdriver = new FirefoxDriver();
					logger.info("Using Firefox");
					return webdriver;
				}catch(Exception e)
				{
					logger.info("启动 Firefox Driver异常："+e.getMessage());
				}
			}
			if (browserType.equals("Chrome")) {
				try
				{
				 System.setProperty("webdriver.chrome.driver",DriverProp.getProperty("DriverPath"));
				 webdriver=new ChromeDriver();
				logger.info("Using Chrome");
				return webdriver;
				}catch(Exception e)
				{
					logger.info("启动 Chrome Driver异常："+e.getMessage());
				}
			}
			if (browserType.equals("IE")) {
				try {
					System.setProperty("webdriver.ie.driver", DriverProp.getProperty("DriverPath"));
					DesiredCapabilities dc = DesiredCapabilities.internetExplorer();
					dc.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		           //IE默认启动保护模式，要么手动在浏览器的设置中关闭保护模式，要么在代码中加上这一句
					dc.setCapability("ignoreProtectedModeSettings", true);
					webdriver = new InternetExplorerDriver(dc);
					webdriver.manage().window().maximize();
					logger.info("Using IE");
					return webdriver;
				}catch(Exception e)
				{
					logger.info("启动 IE Driver异常："+e.getMessage());
				}
			}
		}
		return webdriver;
	}
}