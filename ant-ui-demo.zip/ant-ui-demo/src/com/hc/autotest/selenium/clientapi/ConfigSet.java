package com.hc.autotest.selenium.clientapi;

public class ConfigSet {
	
	public static int timeout;
	public static int stepInterval;

}
