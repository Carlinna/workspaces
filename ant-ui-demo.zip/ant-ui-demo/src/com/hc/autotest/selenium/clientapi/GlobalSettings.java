/**
 * 解析properties文件
 */

package com.hc.autotest.selenium.clientapi;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

/**
 * Global Settings
 * @author 
 */
public class GlobalSettings {
	
	private String fileName;

	public GlobalSettings(String filename){		
		this.fileName = filename;
	}
	
	public String getProperty(String property) {
		Properties prop = getProperties();
		String newProperty="";
		try {
			newProperty = new String(property.getBytes("UTF-8"), "ISO8859_1");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return prop.getProperty(newProperty);
	}
	
	public Properties getProperties() {
		Properties prop = new Properties();
		try {
			FileInputStream file = new FileInputStream(fileName);
			prop.load(file);
			file.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return prop;
	}
	
	 //写入properties信息
    public  void writeProperties(String filePath,String parameterName,String parameterValue) {
     Properties prop = new Properties();
     try {
      InputStream fis = new FileInputStream(filePath);
            //从输入流中读取属性列表（键和元素对）
            prop.load(fis);
            //调用 Hashtable 的方法 put。使用 getProperty 方法提供并行性。
            //强制要求为属性的键和值使用字符串。返回值是 Hashtable 调用 put 的结果。
            OutputStream fos = new FileOutputStream(filePath);
            prop.setProperty(parameterName, parameterValue);
            //以适合使用 load 方法加载到 Properties 表中的格式，
            //将此 Properties 表中的属性列表（键和元素对）写入输出流
            prop.store(fos, "Update '" + parameterName + "' value");
        } catch (IOException e) {
        	System.out.println(e);
        }
    }
}