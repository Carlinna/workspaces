package com.hc.autotest.selenium.clientapi;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.hc.autotest.util.AutoTestUtil;
import com.thoughtworks.selenium.Wait;


public class MyWebDriver implements WebDriver {
	
	private GlobalSettings DriverProp = new GlobalSettings("Prop.properties");
	private int timeout = Integer.parseInt(DriverProp.getProperty("Timeout"));
	//单步暂停时间
	private int stepInterval = Integer.parseInt(DriverProp.getProperty("StepInterval"));
	//循环等待元素加载时间，这里先使用单步暂停时间
	private int waitTime = Integer.parseInt(DriverProp.getProperty("StepInterval"));
	public static int timeLong = 10000;
	public static int timeMiddle = 3000;
	public static int timeShort = 500;
	private  WebDriver driver;
	private AutoTestUtil autotestutil;
	private static Logger logger = Logger.getLogger(MyWebDriver.class
			.getName());
	
	public WebDriver getDriver() {
		return driver;
	}

	public MyWebDriver(AutoTestUtil autoutil) {
		autotestutil = autoutil;
		this.driver=autoutil.getWebDriver();
	}
	
	/**
	 * 点击页面元素<br>
	 * @param locator
	 *            页面元素位置，例如By.xpath("//button[@id='loginBtn']")
	 */
	public void Click(By locator) {
		pause(stepInterval);
		expectElementExistOrNot(true, locator, timeout);
		try {
			driver.findElement(locator).click();
			logger.info("Click " + locator);
		}
		catch(Exception e) {
			autotestutil.handleFailure("Click " + locator + "failed");
		}
	}
	
	/**
	 * 输入文字<br>
	 * @param locator
	 *            输入框位置，例如By.id("username")
	 * @param keys
	 *            要输入的值
	 */
	public void Type(By locator, String keys) {
		pause(stepInterval);
		expectElementExistOrNot(true, locator, timeout);
		try {
			driver.findElement(locator).click();
			driver.findElement(locator).clear();
			driver.findElement(locator).sendKeys(keys);
			logger.info("Type " + keys + " at " + locator);
		}
		catch (Exception e){
			autotestutil.handleFailure("Failed to type " + keys + " at " + locator);
		}
	}
	
	/**
	 * 根据下拉选项的序号选择下拉框<br>
	 @param locator
	 *            下拉框元素位置
	 * @param index
	 *            所选项序号
	 */
	public void SelectByIndex(By locator, int index) {
		pause(stepInterval);
		expectElementExistOrNot(true, locator, timeout);
		try {			
			//driver.findElement(locator).click();
			Select select = new Select(driver.findElement(locator));
			select.selectByIndex(index);
			logger.info("Select by index " + index + " at " + locator);			
		}
		catch (Exception e) {
			autotestutil.handleFailure("Failed to select by index " + index + " at " + locator);
		}
		
	}
	
	/**
	 * 根据下拉选项的文字选择下拉框<br>
	 * @param locator
	 *            下拉框元素位置
	 * @param index
	 *            所选项文字
	 */
	public void SelectByText(By locator, String text) {
		pause(stepInterval);
		expectElementExistOrNot(true, locator, timeout);
		try {
			//driver.findElement(locator).click();
			Select select = new Select(driver.findElement(locator));
			select.selectByVisibleText(text);
			logger.info("Select by text " + text + " at " + locator);			
		}
		catch (Exception e) {
			autotestutil.handleFailure("Failed to select by text " + text + " at " + locator);
		}
		
	}
	
	
	/**
	 * 根据下拉选项的值选择下拉框<br>
	 * @param locator
	 *            下拉框元素位置
	 * @param index
	 *            所选选项的值
	 */
	public void SelectByValue(By locator, String value) {
		pause(stepInterval);
		expectElementExistOrNot(true, locator, timeout);
		try {			
			//driver.findElement(locator).click();
			Select select = new Select(driver.findElement(locator));
			select.selectByValue(value);
			logger.info("Select by value " + value + " at " + locator);			
		}
		catch (Exception e) {
			autotestutil.handleFailure("Failed to select by value " + value + " at " + locator);
		}
		
	}
	
	/**
	 * 点击网页对话框的“确定”按钮<br>
	 */
	public void AcceptAlert() {
		try{
			driver.switchTo().alert().accept();
			logger.info("Accept alert");
		}
		catch(Exception e){
			autotestutil.handleFailure("Failed to accept alert");
		}
	}
	
	/**
	 * 点击网页对话框的“取消”按钮<br>
	 */
	public void DismissAlert() {
		try{
			driver.switchTo().alert().dismiss();
			logger.info("Dismiss alert");
		}
		catch(Exception e){
			autotestutil.handleFailure("Failed to dismiss alert");
		}
	}
	
	/**
	 * 双击页面元素<br>
	 * @param locator
	 *            页面元素位置
	*/
	public void DoubleClick(By locator) {
		pause(stepInterval);
		expectElementExistOrNot(true, locator, timeout);
		try {
			Actions action = new Actions(driver);
			action.doubleClick(driver.findElement(locator));
			logger.info("DoubleClick " + locator);
		}
		catch(Exception e) {
			autotestutil.handleFailure("DoubleClick " + locator + "failed");
		}
	}
	
	/**
	 * 页面拖拽，向上拖拽页面<br>
	 * 功能不稳定，需要继续修改<br>
	 * @param locator
	 *            拖拽的起始元素xpath,例如//input[@id='username']
	*/
	public void PageDrag(By locator) {
		Actions actions = new Actions(driver);
		try {
			
			for (int i=0; i<1000; i++) {
				
				actions.moveByOffset(0, 0);
				actions.clickAndHold();
				actions.moveByOffset(0, 1000);
				actions.release();
				actions.moveByOffset(0, -1000);
			}			
		}
		catch (Exception e){
			autotestutil.handleFailure("Failed to drag page");
		}
	}


	/**
	 * 判定页面元素存在情况是否符合预期<br>
	 * 可用作断言<br>
	 * 预期元素存在, 超时前未找到元素 => 判定为fail<br>
	 * 期望元素不存在, 在超时前找到元素 => 判定为fail<br>
	 * Here <b>exist</b> means <b>visible</b>
	 * @param expectExist
	 *            预期 true or false
	 * @param locator
	 *            需要判定的元素位置
	 * @param timeout
	 *            超时时间，单位为毫秒
	 */
	public void expectElementExistOrNot(boolean expectExist, final By locator, int timeout) {
		if (expectExist) {
			try {
				new Wait() {
					public boolean until() {
						return isElementPresent(locator, -1);
					}
				}.wait("Failed to find element " + locator, timeout);
			} catch (Exception e) {
				//e.printStackTrace();
				autotestutil.handleFailure("Failed to find element " + locator);
			}
			logger.info("Found desired element " + locator);
		} else {
			if (isElementPresent(locator, timeout)) {
				autotestutil.handleFailure("Found undesired element " + locator);
			} else {
				logger.info("Not found undesired element " + locator);
			}
		}
	}
	
	/**
	 * 判定元素是否存在<br>
	 * @param locator
	 *            需要判定的元素位置
	 * @param time           
	 *            在页面上检测元素前等待的时间（毫秒）;<br>
	 *            负的时间表示立即检测元素
	 * @return
	 */
	public boolean isElementPresent(By locator, int time) {
		pause(time);
		try {
			driver.findElement(locator);
			logger.info("Found element " + locator);
			return true;
		}
		catch (Exception e) {
			logger.info("Not found element " + locator);
			return false;
		}		
	}
	
	/**
	 * 循环等待元素加载<br>
	 * @param locator
	 *            需要等待的元素位置
	 * @param time           
	 *            在页面上检测元素前等待的时间（毫秒）;<br>
	 *            负的时间表示立即检测元素
	 * @return
	 */
	public void WaitForElement(By locator) {
		try{
			for (int i=0;i<20;i++) {
				try {
					driver.findElement(locator);
					break;
				}
				catch(Exception e) {
					pause(waitTime);
					logger.info("wait for element " + locator);
				}
			}
		}
		catch(Exception e){
			autotestutil.handleFailure("Can not find element " + locator);
		}
	}
	
	/**
	 * 判定元素显示文字是否符合预期<br>
	 * @param locator
	 *            需要判定的元素位置
	 * @param text           
	 *            预期的文字
	 * @return
	 */
	public boolean AssertTextEqual(By locator, String text) {
		pause(stepInterval);
		try {
			if (driver.findElement(locator).getText() == text) {
				logger.info("Element " + locator + " text equals" + text);
				return true;
			}
			else {
				autotestutil.handleFailure("Element " + locator + " text not equals" + text);
				return false;
			}
		}
		catch (Exception e) {
			autotestutil.handleFailure("Not found element " + locator);
			return false;
		}
	}
	
	/**
	 * 暂停
	 * 
	 * @param time
	 *            暂停时间，单位为毫秒
	 */
	public void pause(int time) {
		if (time <= 0) {
			return;
		}
		try {
			Thread.sleep(time);
			logger.info("Pause " + time + " ms");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 浏览器刷新
	 */
	public void refresh() {
		pause(stepInterval);
		try {
			driver.navigate().refresh();
			logger.info("Refreshed");
		}
		catch (Exception e) {
			autotestutil.handleFailure("Failed to refresh");
		}
	}
	
	/**
	 * 切换浏览器窗口
	 * @param windowTitle
	 *            要切换窗口的 title
	 */
	public void selectWindow(String windowTitle) {
		pause(stepInterval);
		try {
			for(String tempHandleId: driver.getWindowHandles())
			{
				logger.info("当前窗口个数:"+driver.getWindowHandles().size());
				driver.switchTo().window(tempHandleId);
				if(windowTitle.equals(driver.getTitle()))
				{
					logger.info("Switched to window " + windowTitle);
					driver.switchTo().window(tempHandleId);
				}
			}
		}
		catch (Exception e) {
			autotestutil.handleFailure("Failed to select window " + windowTitle);
		}
	}
	
	@Override
	/**
	 * 退出浏览器
	 */
	public void quit() {
		// TODO Auto-generated method stub
		pause(stepInterval);
		driver.close();
		driver.quit();
		driver=null;
		logger.info("Quitted Browser");
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		driver.close();
	}

	@Override
	public WebElement findElement(By by) {
		// TODO Auto-generated method stub
		return driver.findElement(by);
	}

	@Override
	public List<WebElement> findElements(By by) {
		// TODO Auto-generated method stub
		return driver.findElements(by);
	}

	@Override
	public void get(String url) {
		// TODO Auto-generated method stub
		driver.get(url);
	}

	@Override
	public String getCurrentUrl() {
		// TODO Auto-generated method stub
		return driver.getCurrentUrl();
	}

	@Override
	public String getPageSource() {
		// TODO Auto-generated method stub
		return driver.getPageSource();
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return driver.getTitle();
	}

	@Override
	public String getWindowHandle() {
		// TODO Auto-generated method stub
		return driver.getWindowHandle();
	}

	@Override
	public Set<String> getWindowHandles() {
		// TODO Auto-generated method stub
		return driver.getWindowHandles();
	}

	@Override
	public Options manage() {
		// TODO Auto-generated method stub
		return driver.manage();
	}

	@Override
	public Navigation navigate() {
		// TODO Auto-generated method stub
		return driver.navigate();
	}

	

	@Override
	public TargetLocator switchTo() {
		// TODO Auto-generated method stub
		return driver.switchTo();
	}
	

	/**
	 * Enter the iframe
	 * @param xpath
	 *            the iframe's xpath
	 */
	public void enterFrame(String xpath) {
		pause(stepInterval);
		driver.switchTo().frame(findElementByXPath(xpath));
		logger.info("Entered iframe " + xpath);
	}

	/**
	 * Leave the iframe
	 */
	public void leaveFrame() {
		pause(stepInterval);
		driver.switchTo().defaultContent();
		logger.info("Left the iframe");
	}
	
	/**
	 * Mimic system-level keyboard event
	 * @param keyCode
	 *            such as KeyEvent.VK_TAB, KeyEvent.VK_F11
	 */
	public void pressKeyboard(int keyCode) {
		pause(stepInterval);
		Robot rb = null;
		try {
			rb = new Robot();
		} catch (AWTException e) {
			e.printStackTrace();
		}
		rb.keyPress(keyCode);	// press key
		rb.delay(100); 			// delay 100ms
		rb.keyRelease(keyCode);	// release key
		logger.info("Pressed key with code " + keyCode);
	}
	
	/**
	 * Expect some text exist or not on the page<br>
	 * Expect text exist, but not found after timeout => Assert fail<br>
	 * Expect text not exist, but found after timeout => Assert fail
	 * @param expectExist
	 *            true or false
	 * @param text
	 *            the expected text
	 * @param timeout
	 *            timeout in millisecond
	 *            
	public void expectTextExistOrNot(boolean expectExist, final String text, int timeout) {
		if (expectExist) {
			try {
				new Wait() {
					public boolean until() {
						return isTextPresent(text, -1);
					}
				}.wait("Failed to find text " + text, timeout);
			} catch (Exception e) {
				e.printStackTrace();
				AutoTestUtil.handleFailure("Failed to find text " + text);
			}
			logger.info("Found desired text " + text);
		} else {
			if (isTextPresent(text, timeout)) {
				AutoTestUtil.handleFailure("Found undesired text " + text);
			} else {
				logger.info("Not found undesired text " + text);
			}
		}
	}
		
	/**
	 * Expect an element exist or not on the page<br>
	 * Expect element exist, but not found after timeout => Assert fail<br>
	 * Expect element not exist, but found after timeout => Assert fail<br>
	 * Here <b>exist</b> means <b>visible</b>
	 * @param expectExist
	 *            true or false
	 * @param xpath
	 *            the expected element's xpath
	 * @param timeout
	 *            timeout in millisecond
	 */
	public void expectElementExistOrNot(boolean expectExist, final String xpath, int timeout) {
		if (expectExist) {
			try {
				new Wait() {
					public boolean until() {
						return isElementPresent(xpath, -1);
					}
				}.wait("Failed to find element " + xpath, timeout);
			} catch (Exception e) {
				e.printStackTrace();
				autotestutil.handleFailure("Failed to find element " + xpath);
			}
			logger.info("Found desired element " + xpath);
		} else {
			if (isElementPresent(xpath, timeout)) {
				autotestutil.handleFailure("Found undesired element " + xpath);
			} else {
				logger.info("Not found undesired element " + xpath);
			}
		}
	}
	
	
	/**
	 * Is the element present on the page<br>
	 * Here <b>present</b> means <b>visible</b>
	 * @param xpath
	 *            the expected element's xpath
	 * @param time           
	 *            wait a moment (in millisecond) before search element on page;<br>
	 *            minus time means search element at once
	 * @return
	 */
	public boolean isElementPresent(String xpath, int time) {
		pause(time);
//		boolean isPresent = AutoTestUtil.getWebDriver().findElementByXPath(xpath).isDisplayed();
		boolean isPresent = driver.findElement(By.xpath(xpath)).isDisplayed();
		if (isPresent) {
			logger.info("Found element " + xpath);
			return true;
		} else {
			logger.info("Not found element" + xpath);
			return false;
		}
	}
	
	public WebElement findElementByXPath(String xpath) {
		// TODO Auto-generated method stub
		pause(stepInterval);
		expectElementExistOrNot(true, xpath, timeout);
		WebElement webelement = null;
		try {
			 webelement = driver.findElement(By.xpath(xpath));
		} catch (Exception e) {
			e.printStackTrace();
			autotestutil.handleFailure("Failed to get Object at " + xpath);
		}
	
		logger.info("Failed to get Object at " + xpath);
		return webelement;
	}

}
