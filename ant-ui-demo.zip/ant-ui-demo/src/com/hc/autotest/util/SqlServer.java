
/**
 * 用来连接和插入数据库
 */
package com.hc.autotest.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;

import org.testng.Assert;

import com.hc.autotest.selenium.clientapi.GlobalSettings;

public class SqlServer {

	//先运行insertLog函数初始化该变量，再运行insertErrorLog函数
	String CurrentCompInputData = null;
	String exeStatus = "PASS";
	private GlobalSettings DriverProp = new GlobalSettings("Prop.properties");
	private String dbUrl = DriverProp.getProperty("dbUrl");
	private String user = DriverProp.getProperty("dbUser");
	private String pass= DriverProp.getProperty("dbPwd");
	BigInteger ID;
	/**
	 * 将log文件内容插入数据库的log表(根据ErrorLog文件是否存在判断运行结果)
	 * @param logPath
	 */
	public void insertLog(String logPath){
		
		BufferedReader br = null;
		String line=null;
		String fieldName=null; 
		String fieldValue=null; 
		String sql = null;		
		int row = 0;
		String[][] LogArray =new String[13][2];
		
		
		//打开log文件		
		try {
			br = new BufferedReader(new InputStreamReader(new FileInputStream(logPath),"utf-8"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail("open log file fail!");
		}
		
		//逐行读取log文件，获得LogNew表的字段名称和字段值，写入数组LogArray
		try {
			while((line=br.readLine()) != null){		
				if(line.indexOf("[ERROR]")!=-1){exeStatus = "FAIL";}
				if(judge_Table("Log",line) != null){					
					String tempArray[] = judge_Table("Log",line);
					LogArray[row][0] = tempArray[0];
					LogArray[row][1] = tempArray[1];					
					row ++;	
				}
			}
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail("i/o problems when use readline methods!");
		}
		
		//获得有效的LogArray数组， 获得sql查询语句的字段和值部分		
		for(row = 0; row < 13; row++){
			if(LogArray[row][0] != null){
				if(row == 0){
				fieldName = LogArray[row][0] ;
				fieldValue = "'"+LogArray[row][1]+"'";
				}else {
					fieldName = fieldName + "," + LogArray[row][0];
					fieldValue = fieldValue + "," + "'"+LogArray[row][1]+"'";
				}
			}else break;
		}	
		
		ID = new BigInteger(getMaxID()).add(new BigInteger("1"));
		fieldName = "ID" + "," + fieldName;
		fieldValue = "'"+ID+"'" + "," + fieldValue;
		fieldName = "ExeStatus" + "," + fieldName;
		fieldValue = "'"+exeStatus+"'" + "," + fieldValue;
		sql = "insert into dbo.logSelenium("+fieldName+") values("+fieldValue+")";
		System.out.println(sql);
		insertSQL(sql);

	}
	
	/**
	 * 将Errorlog文件内容插入数据库的Errorlog表
	 * @param ErrorlogPath
	 * @throws UnsupportedEncodingException 
	 */
	public void insertErrorLog(String logPath){
		if (exeStatus=="PASS") return;
		BufferedReader br = null;
		String line;
		String fieldName=null; 
		String fieldValue=null; 
		String maxid=null;
		String sql = null;
		int row = 0;
		String[][] LogArray =new String[5][2];
		
		//打开log文件
		try {			
				br = new BufferedReader(new InputStreamReader(new FileInputStream(logPath),"utf-8"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail("open errorlog file fail!");
		}
		
		//逐行读取log文件，获得LogNew表的字段名称和字段值，写入数组LogArray
		try {
			while((line=br.readLine()) != null){				
				if(judge_Table("ErrorLog",line) != null){
					String tempArray[] = judge_Table("ErrorLog",line);
					LogArray[row][0] = tempArray[0];
					LogArray[row][1] = tempArray[1];
					row ++;
				}
			}
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail("i/o problems when use readline methods!");
		}
		
		//获得有效的LogArray数组， 获得sql查询语句的字段和值部分		
		for(row = 0; row < 5; row++){
			if(LogArray[row][0] != null){
				if(row == 0){
				fieldName = LogArray[row][0] ;   
				fieldValue = "'"+LogArray[row][1]+"'" ;      
				}else {
					fieldName = fieldName + "," + LogArray[row][0];		
					fieldValue = fieldValue + "," + "'"+LogArray[row][1]+"'" ;    
				}
			}else break;
		}	
		
		fieldName = "LogID" + "," + fieldName;
		fieldValue = "'"+ID+"'" + "," + fieldValue;
		if(CurrentCompInputData!=null){
			fieldName = fieldName + "," + "CurrentCompInputData" + "," +"ExeStatus";
			fieldValue = fieldValue + "," + "'"+CurrentCompInputData+"'" + "," +"'"+exeStatus+"'";
		}
		sql = "insert into dbo.ErrorLogSelenium("+fieldName+") values("+fieldValue+")";
		System.out.println(sql);
		insertSQL(sql);

	}
	
     /**
	 * 根据给定的行内容返回log表包含的字段和字段值
	 * @param linevalue
	 * @return
	 */
	public String[] judge_Table(String table, String linevalue){
		String[] DataArray = {null,null};
		if(table.equalsIgnoreCase("Log")){
			if(linevalue.indexOf("FrameName")!=-1){
				DataArray[0] = "FrameName";			
			}else if(linevalue.indexOf("TestSysID")!=-1){
				DataArray[0] = "TestSysID";	
			}else if(linevalue.indexOf("TestTaskID")!=-1){
				DataArray[0] = "TestTaskID";	
			}else if(linevalue.indexOf("TestBatchNo")!=-1){
				DataArray[0] = "TestBatchNo";	
			}else if(linevalue.indexOf("TestSetPath")!=-1){
				DataArray[0] = "TestSetPath";	
			}else if(linevalue.indexOf("BusinessFlowID")!=-1){
				DataArray[0] = "BusinessFlowID";	
			}else if(linevalue.indexOf("BusinessFlowName")!=-1){
				DataArray[0] = "BusinessFlowName";	
			}else if(linevalue.indexOf("CurrentCircle")!=-1){
				DataArray[0] = "CurrentCircle";				
			}else if(linevalue.indexOf("TestAgentIP")!=-1){
				DataArray[0] = "TestAgentIP";	
			}else if(linevalue.indexOf("TestCaseName")!=-1){
				DataArray[0] = "TestCaseName";	
			}else if(linevalue.indexOf("CreateTime")!=-1){
				DataArray[0] = "CreateTime";	
			}else if(linevalue.indexOf("RunningTime")!=-1){
				DataArray[0] = "RunningTime";	
			}else if(linevalue.indexOf("CurrentCompInputData")!=-1){
				DataArray[0] = "CurrentCompInputData";
			}
			
		}
		else if(table.equalsIgnoreCase("ErrorLog")){
			if(linevalue.indexOf("BusinessCompID")!=-1){
				DataArray[0] = "BusinessCompID";	
			}else if(linevalue.indexOf("ErrorDesc")!=-1){
				DataArray[0] = "ErrorDesc";	
			}else if(linevalue.indexOf("ScreenShotaPath")!=-1){
				DataArray[0] = "ScreenShotaPath";	
			}
		}
		if(DataArray[0]!=null){
			String[] array = linevalue.split("::");
			int len = array.length;
			DataArray[1] = array[len-1];
			DataArray[1] = DataArray[1].replaceAll("\'", "\"");
			
			//处理数据CurrentCompInputData，该字段存放在info文件中，要写入errorlog数据表
			if(DataArray[0]=="CurrentCompInputData"){
				CurrentCompInputData = DataArray[1];
				return null;
			}
			//处理数据RunningTime
			if(DataArray[0]=="RunningTime"){				
				DataArray[1] = DataArray[1].trim();				
			}
			return DataArray;
		}
		else return null;
	}
	
	/**
	 * 连接并插入数据库
	 */
	public void insertSQL(String sql){  
		ExecuteDB handledb = new ExecuteDB();
		if(!handledb.connectDB()){
			 Assert.fail("Connect database Fail!!"); 
		}
		if(!handledb.updateDB(sql)){
			Assert.fail("insert into database Fail!!"); 
		}
		handledb.closeDB();		
	}
	
	/**
	 * 获取dbo.LogNew数据库表中最大的ID值
	 */
	public String getMaxID(){
		
		String maxid=null;
		String sql = "select top 1 ID from dbo.logSelenium order by ID desc";
		  
		ExecuteDB handledb = new ExecuteDB();
		if(!handledb.connectDB()){
			 Assert.fail("Connect database Fail!!"); 
		}
		maxid = handledb.getResult(sql,"ID");
		if(maxid == null){
			Assert.fail("get MaxID in dbo.logSelenium Fail!!"); 
		}
		handledb.closeDB();		
		return maxid;
	}
}