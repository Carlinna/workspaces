package com.hc.autotest.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.io.output.FileWriterWithEncoding;

public class FileUtil {
	
	
	public long createDir(String filepath) {
		try {
			File f = new File(filepath);
			if (!f.exists()) {
				f.mkdirs();
			}
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	public long copyFile(File f1, File f2) throws Exception {
		long time = new Date().getTime();
		int length = 2097152;
		FileInputStream in = new FileInputStream(f1);
		FileOutputStream out = new FileOutputStream(f2);
		FileChannel inC = in.getChannel();
		FileChannel outC = out.getChannel();
		ByteBuffer b = null;
		while (true) {
			if (inC.position() == inC.size()) {
				inC.close();
				outC.close();
				return new Date().getTime() - time;
			}
			if ((inC.size() - inC.position()) < length) {
				length = (int) (inC.size() - inC.position());
			} else
				length = 2097152;
			b = ByteBuffer.allocateDirect(length);
			inC.read(b);
			b.flip();
			outC.write(b);
			outC.force(false);
		}
	}
	
	/**
	 * 获取指定文件夹下所有文件的路径及文件名
	 * @param filelist 返回值存放对象
	 * @param strPath 文件夹路径
	 * @return 范回ArrayList对象（所有文件路径及文件名）
	 */
	public ArrayList<String> refreshFileList(ArrayList<String> filelist, String strPath) {

		File dir = new File(strPath);
		File[] files = dir.listFiles();

		if (files == null)
			return null;
		for (int i = 0; i < files.length; i++) {
			if (files[i].isDirectory()) {
				refreshFileList(filelist,files[i].getAbsolutePath());
			} else {
				filelist.add(files[i].getAbsolutePath());
			}
		}
		return filelist;
	}
	
	/**
	 * 替换文件中字符串
	 * @param filename
	 * @param oldStr
	 * @param replaceStr
	 */
	public void replaceFileByStr(String filename, String[] oldStr,
			String[] replaceStr) {
		try {
			BufferedReader bufReader = new BufferedReader(
					new InputStreamReader(new FileInputStream(
							new File(filename))));

			StringBuffer strBuf = new StringBuffer();
			for (String tmp = null; (tmp = bufReader.readLine()) != null; tmp = null) {
				// 在这里做替换操作
				for (int i=0;i<oldStr.length;i++){
					tmp = tmp.replaceAll(oldStr[i], replaceStr[i]);
				}
				strBuf.append(tmp);
				strBuf.append(System.getProperty("line.separator"));
			}
			bufReader.close();

			PrintWriter printWriter = new PrintWriter(filename);
			printWriter.write(strBuf.toString().toCharArray());
			printWriter.flush();
			printWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 复制文件，并替换文件中字符串
	 * @param f1Str
	 * @param f2Str
	 * @param oldStr
	 * @param replaceStr
	 */
	public void copyAndReplace(String f1Str,String f2Str, String oldStr[], String replaceStr[]){
		File f1 = new File(f1Str);
		File f2 = new File(f2Str);
		 try {
			 	copyFile(f1, f2);
			 } catch (Exception e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
			 }
		 replaceFileByStr(f2Str, oldStr, replaceStr);
	}
	
	  /**  
     * 追加文件：使用FileWriter  
     *   
     * @param fileName  
     * @param content  
     */  
    public void appendFile(String fileName, String content) { 
    	FileWriterWithEncoding writer = null;
        try {   
            // 打开一个写文件器，构造函数中的第二个参数true表示以追加形式写文件   
//            writer = new FileWriter(fileName, true); 
        	  writer = new FileWriterWithEncoding(fileName, "UTF-8", true);
             writer.write(content);     
        } catch (IOException e) {   
            e.printStackTrace();   
        } finally {   
            try {   
            	if(writer != null){
            		writer.close();   
            	}
            } catch (IOException e) {   
                e.printStackTrace();   
            }   
        } 
    }   
    
    /**
     *  根据路径删除指定的目录或文件，无论存在与否
     *@param sPath  要删除的目录或文件
     *@return 删除成功返回 true，否则返回 false。
     */
    public boolean DeleteFolder(String sPath) {
    	boolean  flag = false;
    	File file = new File(sPath);
        // 判断目录或文件是否存在
        if (!file.exists()) {  // 不存在返回 false
            return flag;
        } else {
            // 判断是否为文件
            if (file.isFile()) {  // 为文件时调用删除文件方法
                return deleteFile(sPath);
            } else {  // 为目录时调用删除目录方法
                return deleteDirectory(sPath);
            }
        }
    }
    
    /**
     * 删除目录（文件夹）以及目录下的文件
     * @param   sPath 被删除目录的文件路径
     * @return  目录删除成功返回true，否则返回false
     */
    public boolean deleteDirectory(String sPath) {
        //如果sPath不以文件分隔符结尾，自动添加文件分隔符
        if (!sPath.endsWith(File.separator)) {
            sPath = sPath + File.separator;
        }
        File dirFile = new File(sPath);
        //如果dir对应的文件不存在，或者不是一个目录，则退出
        if (!dirFile.exists() || !dirFile.isDirectory()) {
            return false;
        }
        boolean flag = true;
        //删除文件夹下的所有文件(包括子目录)
        File[] files = dirFile.listFiles();
        for (int i = 0; i < files.length; i++) {
            //删除子文件
            if (files[i].isFile()) {
                flag = deleteFile(files[i].getAbsolutePath());
                if (!flag) break;
            } //删除子目录
            else {
                flag = deleteDirectory(files[i].getAbsolutePath());
                if (!flag) break;
            }
        }
        if (!flag) return false;
        //删除当前目录
        if (dirFile.delete()) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * 删除单个文件
     * @param   sPath    被删除文件的文件名
     * @return 单个文件删除成功返回true，否则返回false
     */
    public boolean deleteFile(String sPath) {
    	boolean flag = false;
    	File  file = new File(sPath);
        // 路径为文件且不为空则进行删除
        if (file.isFile() && file.exists()) {
            file.delete();
            flag = true;
        }
        return flag;
    }
    
    
    public boolean clearFile(String sPath){
    	boolean flag = false;
    	File f = new File(sPath);
		FileWriter fw;
		try {
			fw = new FileWriter(f);
			fw.write("");
			fw.close();
		    flag = true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
    }

    /**
     * 判断文件是否为空
     * @param sPath
     * @return
     */
    public boolean isemptyFile(String sPath){    
    	File  file = new File(sPath);
    	if(file.length()==0){
    		return false;
    	}else return true;
    }
}
