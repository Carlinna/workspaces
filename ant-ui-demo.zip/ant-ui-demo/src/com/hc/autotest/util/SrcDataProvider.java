package com.hc.autotest.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.TreeMap;

public class SrcDataProvider {
	
	/**
	 * 根据excel整理DateProvider
	 * @return
	 * 		返回DateProvider数组
	 */
	public Iterator<Object[]> SrcDataPro(String oldExcel, String NewExcel){
		
		oTestMain otestmain = new oTestMain();
		ExcelUtil excelUtil = new ExcelUtil();
		ArrayList<Object[]> list = new ArrayList<Object[]>();	
		
		TreeMap<String, String> tm = otestmain.getFlowNameAndRow(oldExcel,NewExcel,"Main", "Flow");
		Iterator<Entry<String, String>> iterator = tm.entrySet().iterator();
		
		//遍历每个excel中的Flow
		while (iterator.hasNext()) {
			Object o = iterator.next();
			String key = o.toString();
			
			//解析当前Flow位置，获得开始行位置，结束行位置
			int leftRow = otestmain.getTopLeftRow(key, "=", "&");
			int rightRow = otestmain.getRightRow(key, "=", "&");

			//获取当前flow循环次数
			int runTime = otestmain.getRunCnt(NewExcel, "Main", 2, leftRow);

			//判断当前flow是否enable
			String flowEnable = excelUtil.ReadExcel(NewExcel, "Main", 10,leftRow);
			
			String flowName = excelUtil.ReadExcel(NewExcel, "Main", 0,leftRow);
			
			String FlowInfo = flowName+"["+leftRow+"-"+rightRow+"]";
			
			
			if (flowEnable.equals("Enable")) {
						for(int j = 1; j <= runTime; j++){	
							Object[] src_data = {FlowInfo,j};
							list.add(src_data);
							}
						}
					}	
			Iterator<Object[]> iteratorFlow = list.iterator();
			return iteratorFlow;
		
		}
}
