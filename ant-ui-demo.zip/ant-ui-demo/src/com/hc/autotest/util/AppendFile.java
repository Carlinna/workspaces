package com.hc.autotest.util;

import java.io.File;

import com.hc.autotest.selenium.clientapi.GlobalSettings;


/**
 *
 * 
 */
public class AppendFile {
	FileUtil fileUtil = new FileUtil();
	private GlobalSettings DriverProp = new GlobalSettings("Prop.properties");
	private String threadcount = DriverProp.getProperty("thread-count");
	private String reruntimes = DriverProp.getProperty("reruntimes");
	
	 public  void writeSuite(String excelPath){
	    	try{
				fileUtil.appendFile(excelPath, "<suite reruntimes=\""+reruntimes+"\" name=\"demo\" thread-count=\""+threadcount+"\" parallel=\"tests\" >");
				fileUtil.appendFile(excelPath, "\n");

			}catch(Exception e){
				System.out.println(e);
			}
	    }
    
    public  void writeFile(String excelPath,String xmlPath,String index){
    	try{
    		String excelName=new File(excelPath).getName();
			FileUtil fileUtil = new FileUtil();
			fileUtil.appendFile(xmlPath, "\t<test name=\""+excelName+"\" >");
			fileUtil.appendFile(xmlPath, "\n");
			fileUtil.appendFile(xmlPath, "\t\t<classes>");
			fileUtil.appendFile(xmlPath, "\n");
			fileUtil.appendFile(xmlPath, "\t\t\t<class name=\"com.hc.autotest.run.TestNgRun"+index+"\" />");
			fileUtil.appendFile(xmlPath, "\n");
			fileUtil.appendFile(xmlPath, "\t\t</classes>");
			fileUtil.appendFile(xmlPath, "\n");
			fileUtil.appendFile(xmlPath, "\t</test>");
			fileUtil.appendFile(xmlPath, "\n");
			fileUtil.appendFile(xmlPath, "\r");
//			fileUtil.appendFile(excelPath, "</suite>");
			
		}catch(Exception e){
			System.out.println(e);
		}
    }

}
