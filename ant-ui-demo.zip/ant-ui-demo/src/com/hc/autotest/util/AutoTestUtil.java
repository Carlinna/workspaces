package com.hc.autotest.util;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.apache.log4j.Logger;

import com.hc.autotest.selenium.clientapi.*;

public class AutoTestUtil {
	private String actionName = null;
	private int dataList;
	private String excelPath;
	private WebDriver webDriver;
	private ExcelUtil excelUtil = new ExcelUtil();
	private GlobalSettings DriverProp = new GlobalSettings("Prop.properties");
	
	private LogTools log = new LogTools();
	private Logger logger = Logger.getLogger(MyWebDriver.class.getName());
	
	private String mylog = new String();
	private String data = new String();
	
	public void StartWebDriver()
	{
		try
		{
			MyWebDriverFactory myAutoTestFactory = new MyWebDriverFactory();
			this.webDriver = myAutoTestFactory.getWebDriverClient();
		}catch(Exception ex)
		{
			Assert.fail("启动Driver异常");
		}
	}
	
	public  WebDriver getWebDriver() {
		return this.webDriver;
	}
	
	public void SetActionName(String excelpath, String actionName, int dataList) {
		this.actionName = actionName;
		this.dataList = dataList;
		this.excelPath = excelpath;
	}
	
	public void handleFailure(String notice) {
		// TODO Auto-generated method stub
		String png = log.screenShot(this);
		String log = notice + " >> capture screenshot at " + png + "\nError action :" + actionName;
		
		for (int i=1;;i++) {
			if (!excelUtil.isEmpty(excelPath, actionName, 0, i)) {
				data += "["+excelUtil.ReadExcel(excelPath, actionName, 0, i)+"]: ";
				data += excelUtil.ReadExcel(excelPath, actionName, dataList+2, i)+", "; 
			}
			else break;
		}
				
		mylog += "\n[ERROR] BusinessCompID:: " + actionName;
		mylog += "\n[ERROR] CurrentCompInputData:: " + data;
		mylog += "\n[ERROR] ErrorDesc:: " + notice;
		mylog += "\n[ERROR] ScreenShotPath:: " + png;
		
		logger.error("BusinessCompID:: " + actionName);
		logger.error("CurrentCompInputData:: " + data);
		logger.error("ErrorDesc:: " + notice);
		logger.error("ScreenShotPath:: " + png);
		data = null;
		Assert.fail(log);
	}
	
	public void CommonLog(String excelpath, String businessFlowID, String businessFlowName, int runlist, long runningTime, SimpleDateFormat createTime, String className) {
		
		logger.info("FrameName:: Selenium");
		mylog += "\n[INFO] FrameName:: Selenium";
		
		String TestSysID = System.getProperty("user.dir");
		String temp[] = TestSysID.split("\\\\"); 
		if (temp.length > 1) { 
			TestSysID = temp[temp.length - 1]; 
			}
		String TestCaseName = excelpath;
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String date = df.format(new Date());
		TestCaseName = excelpath.replaceAll("C://testTemp//", "").split(" ")[0];
		TestCaseName = TestCaseName.replaceAll(date, "");
		logger.info("TestSysID:: " + TestSysID);
		mylog += "\n[INFO] TestSysID:: " + TestSysID;
		
		String TestTaskID = DriverProp.getProperty("TestTaskID");
		if (TestTaskID == null) {
			TestTaskID = date;
		}
		
		logger.info("TestTaskID:: " + TestTaskID);
		mylog += "\n[INFO] TestTaskID:: " + TestTaskID;
		
		logger.info("TestBatchNo:: ");
		logger.info("TestCaseName:: " + TestCaseName);
		logger.info("TestSetPath:: " + excelpath);
		logger.info("BusinessFlowID:: " + businessFlowID);
		logger.info("BusinessFlowName:: " + businessFlowName);
		logger.info("CurrentCircle:: " + runlist);
		
		mylog += "\n[INFO] TestBatchNo:: ";
		mylog += "\n[INFO] TestCaseName:: " + TestCaseName;
		mylog += "\n[INFO] TestSetPath:: " + excelpath;
		mylog += "\n[INFO] BusinessFlowID:: " + businessFlowID;
		mylog += "\n[INFO] BusinessFlowName:: " + businessFlowName;
		mylog += "\n[INFO] CurrentCircle:: " + runlist;
		
		try {
			String ip = InetAddress.getLocalHost().toString();
			logger.info("TestAgentIP:: " + ip);
			mylog += "\n[INFO] TestAgentIP:: " + ip;
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		mylog += "\n[INFO] CreateTime:: " + createTime.format(new Date());
		mylog += "\n[INFO] RunningTime:: " + runningTime/1000;
		
		logger.info("CreateTime:: " + createTime.format(new Date()));
		logger.info("RunningTime:: " + runningTime/1000 + "s");
		
		//生成日志文件，将mylog输出到文件
		try {
			File logfile = new File(System.getProperty("user.dir") + "\\log\\" + className);
			logfile.createNewFile();
			FileOutputStream outfile = new FileOutputStream(logfile);
			DataOutputStream outlog = new DataOutputStream(outfile);
			outlog.writeUTF(mylog);
			outlog.close();
			outfile.close();
			mylog = null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
