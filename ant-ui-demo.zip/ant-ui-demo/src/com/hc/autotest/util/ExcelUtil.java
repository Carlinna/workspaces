/**
 * Excel操作
 */
package com.hc.autotest.util;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.testng.Assert;

public  class ExcelUtil {
	
	private Logger logger = Logger.getLogger(ExcelUtil.class
			.getName());
	
	
	/**
	 * 判断单元格是否为空
	 * @param testCasePath
	 * @param sheetName
	 * @param col
	 * @param row
	 * @return
	 * 			true 为空,false为不空
	 */
	public boolean isEmpty(String testCasePath,String sheetName,int col,int row){
		boolean flag=false;
		HSSFWorkbook hw = null;
		try {
			FileInputStream fileOut = new FileInputStream(testCasePath); 
			hw = new HSSFWorkbook(fileOut);
			HSSFSheet hsheet = hw.getSheet(sheetName);
	        HSSFRow hrow = hsheet.getRow(row);
	        HSSFCell hcell = hrow.getCell(col);	        
	        switch (hcell.getCellType()){
		        case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BLANK:flag = true;break;		        
		        default:flag = false;break;
	        }	    	        
	        fileOut.close();
		} catch (Exception e) {
			flag= true;
		}
		return flag;
	}
	
	/**
	 * 读Excel
	 * @param testCasePath
	 * 				Excel路径和名称
	 * @param sheetName  
	 * 				需要读取的sheet名称
	 * @param col
	 * 				指定列
	 * @param row
	 *   			指定行
	 * @return
	 * 				返回单元格中的文本信息
	 */			
	public String ReadExcel(String testCasePath,String sheetName,int col,int row){
		String result="";
		HSSFWorkbook hw = null;
		try {
			FileInputStream fileOut = new FileInputStream(testCasePath); 
			hw = new HSSFWorkbook(fileOut);
			HSSFSheet hsheet = hw.getSheet(sheetName);
	        HSSFRow hrow = hsheet.getRow(row);
	        HSSFCell hcell = hrow.getCell(col);
	        HSSFFormulaEvaluator evaluator;
	        
	        switch (hcell.getCellType()){
		        case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BLANK:result="";break;
		        case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_NUMERIC:
		        	 evaluator = new HSSFFormulaEvaluator(hw);
				     result = String.valueOf((int)evaluator.evaluate(hcell).getNumberValue());
				     break;
		        case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_FORMULA:
		        	 evaluator = new HSSFFormulaEvaluator(hw);
				     result = evaluator.evaluate(hcell).getStringValue();
				     break;
		        case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING:
		        	 evaluator = new HSSFFormulaEvaluator(hw);
				     result = evaluator.evaluate(hcell).getStringValue();
				     break;
		        default:
		            String log = "Excel cell input type is "+hcell.getCellType();
		        	logger.error(log);
		        	Assert.fail(log);
		        	break;
	        }	     
	        
	        fileOut.close();
		} catch (Exception e) {
			String log="Failed to Read Excel :" + testCasePath+"\nsheetname:"+sheetName+"\ncol:"+col+"\nrow:"+row;
			logger.error(log);
			System.out.println(e);
			Assert.fail(log);
			
		}
        
		return result;
	}
	
	/**
	 * 修改Excel中指定单元格内容
	 * @param oldExcel
	 * @param NewExcel
	 * @param sheetName
	 * @param col
	 * @param row
	 * @param str
	 */
	public void UpdateExcel(String oldExcel,String NewExcel,String sheetName,int col,int row,String str) {
		try {    			
			HSSFWorkbook hw = new HSSFWorkbook(new FileInputStream(NewExcel));     		
			HSSFSheet hsheet = hw.getSheet(sheetName);
	        HSSFRow hrow = hsheet.getRow(row);
	        HSSFCell hcell = hrow.getCell(col);
	        hcell.setCellValue(str);    
	        
	        FileOutputStream out = new FileOutputStream(NewExcel);
	        hw.write(out);
	        out.close();
	       
		  } catch  (Exception e)  {
    	    String log="Failed to update Excel :" + oldExcel+"\nsheetname:"+sheetName+"\ncol:"+col+"\nrow:"+row;
			logger.error(log);
			System.out.println(e);
			Assert.fail(log);
	          
	       } 
	}
	
	public void setForceFormulaRecalculation(String NewExcel){
		try {    			
			HSSFWorkbook hw = new HSSFWorkbook(new FileInputStream(NewExcel));     		
			HSSFSheet sheet1 = hw.getSheet("DataSummary");
	        sheet1.setForceFormulaRecalculation(true);
	        FileOutputStream out = new FileOutputStream(NewExcel);
	        hw.write(out);
	        out.close();
		  } catch  (Exception e)  {
			  String log="Failed to setForceFormulaRecalculation Excel :" + NewExcel;
				logger.error(log);
				System.out.println(e);
				Assert.fail(log);
	       } 
	}
}
	