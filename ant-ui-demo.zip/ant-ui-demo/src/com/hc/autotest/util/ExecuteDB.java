/**
 * 数据库处理函数集合
 */
package com.hc.autotest.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.hc.autotest.selenium.clientapi.GlobalSettings;

public class ExecuteDB {

	private GlobalSettings DriverProp = new GlobalSettings("Prop.properties");
	private String dbUrl = DriverProp.getProperty("dbUrl");
	private String user = DriverProp.getProperty("dbUser");
	private String pswd= DriverProp.getProperty("dbPwd");
	
	Connection dbConn=null; 
	
	/**
	 * 连接数据库
	 * @return
	 */
	public boolean connectDB(){		        
	    try {
			dbConn = DriverManager.getConnection(dbUrl,user,pswd);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();		
			return false;
		}  
	    return true;
        
	}
	
	/**
	 * 关闭数据库连接
	 */
	public void closeDB(){
	    try {
			dbConn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 更新数据库
	 * @param sql
	 * 		需更新的sql语句
	 * @return
	 */
	public boolean updateDB(String sql){
		PreparedStatement ps;
		try {
			ps = dbConn.prepareStatement(sql);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	/**
	 * 查询数据库
	 * @param sql
	 * 			需要查询的sql语句
	 * @return 返回查询结果ResultSet集合
	 */
	public ResultSet selectDB(String sql){
		PreparedStatement ps;
		ResultSet rs = null;
		try {
			ps = dbConn.prepareStatement(sql);
			rs = ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return rs;
		}		
		return rs;	
	}
	
	/**
	 * 获取数据库查询记录
	 * 
	 * @param sql
	 *           需要查询的sql语句
	 * @return 将查询出的记录用；连接，String类型返回
	 */
	public String getResult(String sql, String columnLabel) {
		Statement sm;
		ResultSet rs = null;
		String result = "";
		try {
			sm = dbConn.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			rs = sm.executeQuery(sql);		
			String temp;
			while (rs.next()) {
				if (!rs.isLast()) {
					temp = rs.getString(columnLabel) + "$ROW";
				} else {
					temp = rs.getString(columnLabel);
				}
				result = result + temp;
			}			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		return result;
	}
	
	/**
	 * 查询出的记录数目 
	 * @param sql
	 * 			 需要查询的sql语句
	 * @return 查询出的记录条数
	 */
	public int getRowCount(String sql) {
		Statement sm;
		ResultSet rs = null;
		int rowCount = 0;
		try {
			sm = dbConn.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			rs = sm.executeQuery(sql);
			rs.last();			
			rowCount = rs.getRow();				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
		return rowCount;
	}


}
