package com.hc.autotest.util;

import java.util.ArrayList;
import java.util.Iterator;

import com.hc.autotest.selenium.clientapi.GlobalSettings;
import com.hc.autotest.util.FileUtil;

public class FileSystem {

	public static void main(String[] args) {
		//生成 java 文件
		FileUtil fileUtil = new FileUtil();
		FileSystem fileSystem = new FileSystem();
		String xmlPath = "test-xml/demo.xml";
		
		String testCaseDemoJava = "src/com/hc/autotest/common/TestNgRun.java";
		String testCaseJava = "src/com/hc/autotest/run";
		String testCaseNamePro = "testcasename.properties";
		GlobalSettings globalSettings = new GlobalSettings(testCaseNamePro);
		
		String testCaseExcel = "testcase/test";
		
		String[] oldStr={"TestNgRun","com.hc.autotest.common"};
		
		fileUtil.DeleteFolder(testCaseJava);
		fileUtil.createDir(testCaseJava);
		
		fileUtil.DeleteFolder(testCaseNamePro);
		fileUtil.clearFile(testCaseNamePro);
		
		fileUtil.clearFile(xmlPath);
		fileSystem.writeSuiteInXml(xmlPath);
		
		 ArrayList<String> filelist = new ArrayList<String>();
		
		 filelist= fileUtil.refreshFileList(filelist,testCaseExcel);
		 if (filelist.size()!=0){
		 Iterator<String> it= filelist.iterator();
		 int i=0;
		 while(it.hasNext()){
			 String excelPath=it.next();
			 if (excelPath.endsWith(".xls") || excelPath.endsWith(".xlsx")){
				 System.out.println(excelPath);
				 String str = excelPath.replaceAll("\\\\", "\\\\\\\\\\\\\\\\");
				String[] replaceStr={"","com.hc.autotest.run"};
				 replaceStr[0] = oldStr[0]+String.valueOf(i+1);
				 fileUtil.copyAndReplace(testCaseDemoJava,testCaseJava+"\\TestNgRun"+String.valueOf(i+1)+".java",oldStr,replaceStr);
				 
				 globalSettings.writeProperties(testCaseNamePro, "TestNgRun"+String.valueOf(i+1), excelPath);
				 
				 new AppendFile().writeFile(excelPath,xmlPath,String.valueOf(i+1));
				 
				 i++;
				 System.out.println("测试管理器："+i);
			 }
			
		 }
		 
		 fileUtil.appendFile(xmlPath, "</suite>");
		 }else{
		 System.out.println("文件夹下没有文件");
		 }
	}
	
	
	//生成xml
	public void writeXml(String excelPath,String xmlPath,String index){
		AppendFile afile= new AppendFile();
		afile.writeFile(excelPath,xmlPath,index);
	}
	
	//生成xml
		public void writeSuiteInXml(String excelPath){
			AppendFile afile= new AppendFile();
			afile.writeSuite(excelPath);
		}
}
