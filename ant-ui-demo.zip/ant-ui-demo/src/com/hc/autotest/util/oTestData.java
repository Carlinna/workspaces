package com.hc.autotest.util;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.hc.autotest.util.*;

public class oTestData {
	private Logger logger = Logger.getLogger(oTestData.class
			.getName());

	private AutoTestUtil driver;
	public String testCasePath;
	public String sheetName;
	public int col;
	public HashMap<String, Integer> hashmap;	
	
	ExcelUtil excelUtil = new ExcelUtil(); 
	
	public oTestData(String testcasepath, String sheetname,int dataList,HashMap<String, Integer> hm){
	    this.testCasePath = testcasepath;
	    this.sheetName = sheetname;
	    this.col = dataList +2;
	    this.hashmap = hm;
	}
	

	public String GetItem(String fieldName){
		int row=0;
		try {
			 row = hashmap.get(fieldName); 		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			driver.handleFailure("获取数据字段失败,数据获取字段为："+fieldName);
			e.printStackTrace();
		}
		return excelUtil.ReadExcel(testCasePath,sheetName,col,row);
	}
	
		
	public void setItem(String fieldName,String setData){
		int row=0;
		try {
			row = hashmap.get(fieldName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			driver.handleFailure("回填数据字段失败===数据字段为："+fieldName +"   数据值："+setData);
			e.printStackTrace();
		} 
		excelUtil.UpdateExcel(testCasePath, testCasePath, sheetName, col, row, setData);
	}
	
	/**
	 * 判断是否存在指定的数据字段
	 * @param hm
	 * 			从Action的getRowWithTestData()获取hashmap
	 * @param testData
	 * 			需校验的数据字段
	 * @return
	 * 			true - 存在
	 * 			false - 不存在
	 */
	public boolean isExist(String fieldName){
		return hashmap.containsKey(fieldName);
	}
}
