package com.hc.autotest.util;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TreeMap;


import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.testng.Assert;

import com.hc.autotest.util.*;

public class oTestMain {
	
	private Logger logger = Logger.getLogger(oTestMain.class
			.getName());
	
	private ExcelUtil excelUtil = new ExcelUtil();
	
	/**
	 * 返回Excel各个flow开始行和结束行位置
	 * @param testCasePath
	 * 				Excel路径
	 * @param sheetName
	 * 				sheet页名称
	 * @param str
	 * 				目前是以"Flow"分割
	 * @return
	 *         		返回各个flow的开始行和结束行位置
	 */
	@SuppressWarnings("resource")
	public TreeMap<String, String> getFlowNameAndRow (String oldExcel,String NewExcel,String sheetName,String str){
		TreeMap<String, String> tm = new TreeMap<String, String>();
		//复制excel
		try {
			 FileChannel fcin = new FileInputStream(oldExcel).getChannel();   
             FileChannel fcout = new FileOutputStream(NewExcel).getChannel();      	              
             fcin.transferTo(0, fcin.size(), fcout);   
             fcin.close();   
             fcout.close();   
             
             FileInputStream is = new FileInputStream(NewExcel);
             HSSFWorkbook hw = new HSSFWorkbook(is);     		
 			 HSSFSheet hsheet = hw.getSheet(sheetName);
 	         int a  = hsheet.getNumMergedRegions();    	     
 	         for(int j=0;j<a;j++){
 	        	CellRangeAddress hcell=hsheet.getMergedRegion(j);
 	        	 //只取第一列
 	        	 if(hcell.getFirstColumn()==0){
 	        		 int firstrow = hcell.getFirstRow();
 	        		 String flowname =  hsheet.getRow(firstrow).getCell(0).getStringCellValue();
 	        		 tm.put(flowname, firstrow+"&"+hcell.getLastRow());
 	        	 }
 	         }
			 is.close();
		} catch (Exception e) {
			   String log="Failed to getFlowNameAndRow in  Excel :" + NewExcel+"\nsheetname:"+sheetName;
				logger.error(log);
				Assert.fail(log);
			System.out.println(e);
		}
		return tm;
		
	}

	/**
	 * 判断流程或组件是否Enable
	 * @param testCasePath
	 * @param sheetName
	 * @param col
	 * @param row
	 * @return
	 */
	public boolean isEnable(String testCasePath,String sheetName,int col,int row){
		boolean flag = false;
		 String result=excelUtil.ReadExcel(testCasePath ,sheetName , col ,row );
		 try {
			if ( result.equals("Enable")){
				flag = true;
			}else{
				flag = false;
			}
			} catch (Exception e) {
				String log="Failed to Read Excel :" + testCasePath+"\nsheetname:"+sheetName+"\ncol: "+col+"\nrow:"+row;
				logger.error(log);
				Assert.fail(log);
				System.out.println(e);
			}
		return flag;
	}
	
	/**
	 * 获取流程循环次数
	 * @param testCasePath
	 * @param sheetName
	 * @param col
	 * @param row
	 * @return
	 */
	public int getRunCnt(String testCasePath,String sheetName,int col,int row){
		 String result=excelUtil.ReadExcel(testCasePath ,sheetName , col ,row );
		return  Integer.parseInt(result);
	}

	/**
	 * 解析返回的流程编号、起始行和结束行位置，返回流程编号
	 * 注：目前流程编号和行数是以 ' = ' 分割，起始行和结束行是用 ‘ & ’ 分割
	 * @param tempStr
	 * @param str
	 * @return
	 */
	public String getTopLeftContents(String tempStr,String str){
		   String[] strarray=tempStr.split(str); 
		   return strarray[0];
	}
	
	/**
	 * 解析返回的流程编号、起始行和结束行位置，返回起始行位置
	 * 注：目前流程编号和行数是以 ' = ' 分割，起始行和结束行是用 ‘ & ’ 分割
	 * @param tempStr 
	 * @param str1 目前是用 ‘ = ’
	 * @param str2 目前是用 ‘ & ’
	 * @return
	 */
	public int getTopLeftRow(String tempStr,String str1,String str2){
		   String[] strarray=tempStr.split(str1); 
		   String rows=strarray[1];
		   String[] topLeftRow=rows.split(str2);
		   return Integer.parseInt(topLeftRow[0]);
	}
	
	/**
	 * 解析返回的流程编号、起始行和结束行位置，返回结束行位置
	 * 注：目前流程编号和行数是以 ' = ' 分割，起始行和结束行是用 ‘ & ’ 分割
	 * @param tempStr
	 * @param str1 目前是用 ‘ = ’
	 * @param str2 目前是用 ‘ & 
	 * @return
	 */
	public int getRightRow(String tempStr,String str1,String str2){
		   String[] strarray=tempStr.split(str1); 
		   String rows=strarray[1];
		   String[] topLeftRow=rows.split(str2);
		   return Integer.parseInt(topLeftRow[1]);
	}
	
	/**
	 * 获取当前时间
	 * @param simpleDateFormat
	 * 			设置日期格式
	 * @return
	 */
	public String getNowTime(String simpleDateFormat){
		SimpleDateFormat df = new SimpleDateFormat(simpleDateFormat);//设置日期格式
		return df.format(new Date());
	}
	
	/**
	 * 得到当前循环的数据列
	 * @param RunList 
	 * 			当前的循环次数。默认第一次运行值为1。
	 * @param Row
	 * 			行数，是第几行
	 * @return
	 * 			返回当前的数据列
	 */
	public int getCurrentDataList(String Excel_Path, int RunList, int Row){

		String DateList = excelUtil.ReadExcel(Excel_Path, "Main", 5, Row);
			
		//数据列格式为1-9
		if(DateList.indexOf("-") > 0){
			String DateArray[] =  DateList.split("-");
			int StartNum = Integer.parseInt(DateArray[0]); //起始数据列
			int EndNum = Integer.parseInt(DateArray[1]);   //结束数据列
			int AllCnt = EndNum - StartNum + 1;  //数据列总列数
			if(RunList % AllCnt == 0)
				return EndNum;
			else return StartNum + RunList % AllCnt - 1;
		}		
		//数据列格式为1,2,3,4,5,6,7,8,9
		else if(DateList.indexOf(",") > 0){
			String DateArray[] = DateList.split(",");
			int AllCnt = DateArray.length;  //AllCnt为总数据列
			if(RunList % AllCnt == 0){
				return Integer.parseInt(DateArray[AllCnt - 1]);
			}
			else return Integer.parseInt(DateArray[RunList % AllCnt - 1]); 
		}
		
		//只有一行数据列
		else return Integer.parseInt(DateList);
	}
	
	
	public boolean isActionRun(String Excel_Path,String ActName, int DataList){
		 String result=excelUtil.ReadExcel(Excel_Path ,ActName , 0 ,1 );
		 if(result.equals("$运行标识")){
			 String runOrNot = excelUtil.ReadExcel(Excel_Path ,ActName , DataList+2 ,1 );
			 if(runOrNot.equals("否")){
				 return false;
			 }else return true;
				
		 }else return true;
		
	}
}
